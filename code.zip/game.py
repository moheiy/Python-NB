import random

# 生成随机数
number = random.randint(1, 10)

# 游戏开始
print('猜数字游戏开始！')

# 循环猜数字
while True:
    guess = int(input('请输入一个数字（1-10）：'))
    if guess == number:
        print('恭喜你，猜对了！')
        break
    elif guess < number:
        print('太小了，再试试！')
    else:
        print('太大了，再试试！')